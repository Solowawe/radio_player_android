"""
main.py — Android-приложение радио-плеера (Kivy + KivyMD).

Возможности:
  - Radio Record: 60+ станций без рекламы
  - Локальные аудиофайлы
  - Воспроизведение по прямой ссылке
  - Материальный дизайн (KivyMD)
"""

import os
import sys
from pathlib import Path

from kivy.config import Config

# Настройки окна (для десктоп-тестирования; на Android игнорируются)
Config.set('graphics', 'width', '420')
Config.set('graphics', 'height', '700')
Config.set('graphics', 'resizable', False)
Config.set('kivy', 'window_icon', '')

from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.metrics import dp
from kivy.utils import platform
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.lang import Builder

from kivymd.app import MDApp
from kivymd.uix.list import OneLineAvatarIconListItem, IconLeftWidget, TwoLineListItem
from kivymd.uix.button import MDRaisedButton, MDFlatButton, MDIconButton
from kivymd.uix.dialog import MDDialog
from kivymd.uix.snackbar import Snackbar
from kivymd.uix.toolbar import MDTopAppBar
from kivymd.uix.progressbar import MDProgressBar
from kivymd.uix.slider import MDSlider
from kivymd.uix.label import MDLabel
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd import fonts

from music_player import MusicPlayer, Track

# ──────────────────────────────────────────────
# KV-разметка (встроенная)
# ──────────────────────────────────────────────

KV = '''
<MainScreen>:
    BoxLayout:
        orientation: 'vertical'
        spacing: '4dp'
        padding: '4dp'

        MDTopAppBar:
            title: 'Radio Player'
            md_bg_color: app.theme_cls.primary_color
            specific_text_color: 1, 1, 1, 1
            left_action_items: [['menu', lambda x: app.open_menu()]]
            right_action_items: [['dots-vertical', lambda x: app.open_menu()]]

        # Информация о текущем треке
        MDLabel:
            id: track_label
            text: '🎵  Нет трека'
            halign: 'center'
            font_style: 'H6'
            size_hint_y: None
            height: '48dp'

        # Ползунок позиции (условный)
        MDProgressBar:
            id: progress_bar
            value: 0
            max: 100
            size_hint_y: None
            height: '4dp'

        # Кнопки управления
        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: '64dp'
            spacing: '8dp'
            padding: ['16dp', '0dp', '16dp', '0dp']

            MDIconButton:
                icon: 'skip-previous'
                on_release: app.player.play_prev()

            Widget:

            MDIconButton:
                id: play_btn
                icon: 'play'
                theme_icon_size: 'Custom'
                icon_size: '48dp'
                on_release: app.toggle_play_pause()

            Widget:

            MDIconButton:
                icon: 'skip-next'
                on_release: app.player.play_next()

        # Громкость
        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: '48dp'
            spacing: '8dp'
            padding: ['16dp', '0dp', '16dp', '0dp']

            MDIconButton:
                icon: 'volume-high'
                on_release: app.show_volume_dialog()

            MDSlider:
                id: volume_slider
                min: 0
                max: 100
                value: 50
                on_value: app.set_volume(self.value)

        # Вкладки: Станции / Локальные / Ссылка
        MDTabs:
            id: tabs
            on_tab_switch: app.on_tab_switch(*args)

            Tab:
                title: '📻 Radio Record'
                icon: 'radio'

                ScrollView:
                    MDList:
                        id: stations_list

            Tab:
                title: '💿 Локальные'
                icon: 'folder-music'

                BoxLayout:
                    orientation: 'vertical'
                    spacing: '4dp'

                    MDRaisedButton:
                        text: '📁  Выбрать папку'
                        on_release: app.choose_folder()

                    ScrollView:
                        MDList:
                            id: local_list

            Tab:
                title: '🔗 Ссылка'
                icon: 'link'

                BoxLayout:
                    orientation: 'vertical'
                    spacing: '8dp'
                    padding: '16dp'

                    MDTextField:
                        id: url_input
                        hint_text: 'Введите прямую ссылку на аудио...'
                        mode: 'rectangle'

                    MDRaisedButton:
                        text: '▶  Воспроизвести'
                        on_release: app.play_url()

        # Статус
        MDLabel:
            id: status_label
            text: '💡  Выберите станцию или откройте папку'
            halign: 'center'
            font_style: 'Caption'
            size_hint_y: None
            height: '32dp'
            theme_text_color: 'Hint'
'''


# ──────────────────────────────────────────────
# Экраны
# ──────────────────────────────────────────────

class MainScreen(Screen):
    pass


# ──────────────────────────────────────────────
# Приложение
# ──────────────────────────────────────────────

class RadioPlayerApp(MDApp):
    """Android-приложение радио-плеера."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.player = MusicPlayer()
        self._stations_loaded = False

    def build(self):
        self.theme_cls.primary_palette = 'Blue'
        self.theme_cls.theme_style = 'Dark'
        self.theme_cls.primary_hue = '700'

        Builder.load_string(KV)
        self.screen = MainScreen(name='main')
        self.sm = ScreenManager()
        self.sm.add_widget(self.screen)

        # Загружаем станции при старте
        Clock.schedule_once(lambda dt: self.load_stations(), 0.5)

        return self.sm

    def load_stations(self):
        """Загрузить станции Radio Record."""
        if self._stations_loaded:
            return
        self._stations_loaded = True

        self.show_status('📡  Загрузка станций...')
        stations = self.player.get_record_stations()
        stations_list = self.screen.ids.stations_list
        stations_list.clear_widgets()

        for track in stations:
            item = TwoLineListItem(
                text=track.title,
                secondary_text='📻  Radio Record',
                on_release=lambda x, t=track: self.play_track(t),
            )
            stations_list.add_widget(item)

        self.show_status(f'📻  Загружено {len(stations)} станций')

    def play_track(self, track: Track):
        """Воспроизвести трек."""
        self.player.play_track(track)
        self.screen.ids.track_label.text = f'🎵  {track.display_name}'
        self.screen.ids.play_btn.icon = 'pause'
        self.show_status(f'▶  {track.display_name}')

    def toggle_play_pause(self):
        """Play / Pause."""
        if self.player.is_playing:
            self.player.pause()
            self.screen.ids.play_btn.icon = 'play'
            self.show_status('⏸  Пауза')
        else:
            self.player.play()
            self.screen.ids.play_btn.icon = 'pause'
            name = self.player.current_track.display_name if self.player.current_track else ''
            self.show_status(f'▶  {name}')

    def set_volume(self, value: float):
        """Установить громкость."""
        self.player.volume = value / 100.0

    def show_volume_dialog(self):
        """Показать диалог громкости."""
        # Громкость управляется слайдером напрямую
        pass

    def choose_folder(self):
        """Выбрать папку с музыкой."""
        if platform == 'android':
            from androidstorage4kivy import SharedStorage
            # На Android используем SAF (Storage Access Framework)
            self.show_status('📁  Выберите папку через системный диалог')
            # TODO: интеграция с SAF
        else:
            # Десктоп: используем FileChooser
            content = FileChooserListView(path=os.path.expanduser('~'))
            popup = Popup(
                title='Выберите папку с музыкой',
                content=content,
                size_hint=(0.9, 0.9),
            )
            content.on_submit = lambda selection, touch=None: self._on_folder_selected(selection, popup)
            popup.open()

    def _on_folder_selected(self, selection, popup):
        """Обработать выбор папки."""
        popup.dismiss()
        if not selection:
            return
        folder = selection[0]
        if os.path.isdir(folder):
            tracks = self.player.load_folder(folder)
            local_list = self.screen.ids.local_list
            local_list.clear_widgets()
            for track in tracks:
                item = TwoLineListItem(
                    text=track.title,
                    secondary_text='💿  Локальный',
                    on_release=lambda x, t=track: self.play_track(t),
                )
                local_list.add_widget(item)
            self.show_status(f'📁  Загружено {len(tracks)} треков')

    def play_url(self):
        """Воспроизвести по ссылке."""
        url = self.screen.ids.url_input.text.strip()
        if url:
            self.player.play_url(url)
            self.screen.ids.track_label.text = f'🔗  {url.split("/")[-1][:40]}'
            self.screen.ids.play_btn.icon = 'pause'
            self.show_status('🔗  Воспроизведение по ссылке')

    def on_tab_switch(self, *args):
        """Переключение вкладок."""
        pass

    def open_menu(self):
        """Открыть меню."""
        # TODO: меню с настройками
        pass

    def show_status(self, text: str):
        """Показать статус."""
        self.screen.ids.status_label.text = text

    def on_pause(self):
        """Обработка сворачивания приложения (Android)."""
        return True

    def on_stop(self):
        """Остановка приложения."""
        self.player.cleanup()


# ──────────────────────────────────────────────
# Запуск
# ──────────────────────────────────────────────

if __name__ == '__main__':
    RadioPlayerApp().run()