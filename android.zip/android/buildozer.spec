[app]

# Название приложения
title = Radio Player

# Пакет (уникальный идентификатор)
package.name = radioplayer

# Домен пакета
package.domain = org.radioplayer

# Версия
version.code = 1
version.string = 1.0.0

# Главный файл
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf,otf

# Зависимости (pip)
requirements = python3,kivy==2.3.0,kivymd==1.1.1,requests,urllib3

# Ориентация экрана
orientation = portrait

# Разрешения Android
android.permissions = INTERNET,ACCESS_NETWORK_STATE,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,READ_MEDIA_AUDIO

# API уровень
android.api = 33
android.minapi = 21
android.sdk = 33
android.ndk = 25b
android.gradle_dependencies = 'androidx.media:media:1.6.0'

# Подпись APK
android.allow_backup = true
android.keystore = 
android.keystore.alias = 

# Иконка (можно заменить своей)
# icon = icon.png

# Название APK файла
android.filename = RadioPlayer

# Сжатие
android.archs = arm64-v8a, armeabi-v7a
android.reduce_png = true
android.enable_androidx = true

# Логи
android.logcat_filters = *:S python:V

# Язык
android.strings = en_US,ru_RU

[buildozer]

# Лог сборки
log_level = 2

# Директория для сборки
build_dir = ./.build

# Директория для бинарников
bin_dir = ./bin

[requirements]
# Дополнительные требования для сборки
# (устанавливаются через pip на хосте)
hostpython3 = python3
hostpip = pip3

[app:ios]
# iOS настройки (не используются)

[app:windows]
# Windows настройки (не используются)